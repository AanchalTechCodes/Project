
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;



@WebServlet(urlPatterns={"/delete"})
public class delete extends HttpServlet {
 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        String d1=request.getParameter("d");
        Integer id1=Integer.parseInt(d1);
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/details","root","");
            Statement st=conn.createStatement();
            st.executeUpdate("delete from info where id='"+id1+"' ");
            response.sendRedirect("index.jsp");
        }catch(Exception ex){
            System.out.println("Connection Invalid");
        }
    }
}
