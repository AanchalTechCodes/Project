


import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.*;


@WebServlet(urlPatterns={"/create"})
public class create extends HttpServlet {
   
     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>create</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet create at " + request.getContextPath () + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    } 


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

        
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");
       PrintWriter out=response.getWriter();
       String name=request.getParameter("name");
       String con=request.getParameter("contact");
       String email=request.getParameter("email");
       try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/details","root","");
                PreparedStatement ps=conn.prepareStatement("insert into info(name,contact,email) values(?,?,?)");
                ps.setString(1,name);
                ps.setString(2,con);
                ps.setString(3,email);
                int i=ps.executeUpdate();
                if(i>0){
//                    out.println("registration successfully");
                    response.sendRedirect("index.jsp");
                    
                }else{
                    out.println("registration failed");
                
       }
       } catch (Exception ex) {
           System.out.println("connection Invalid");
//            out.println("connection invalid"+ex.getMessage());
        }
    }

 @Override
        public String getServletInfo() {
        return "Short description";
    }


}

    

