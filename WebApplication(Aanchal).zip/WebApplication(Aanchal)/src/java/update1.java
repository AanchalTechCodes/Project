/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */


import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;



@WebServlet(urlPatterns={"/update1"})
public class update1 extends HttpServlet {


   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
       response.setContentType("text/html");
        PrintWriter out=response.getWriter();
       String name=request.getParameter("name");
       String con=request.getParameter("contact");
       String email=request.getParameter("email");
       String d2=request.getParameter("ids");
       try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/details","root","");
        PreparedStatement ps=conn.prepareStatement("update info set name='"+name+"',contact='"+con+"',email='"+email+"' where id='"+d2+"' "); 
        ps.executeUpdate();
        response.sendRedirect("index.jsp");
        
        }catch(Exception ex){
          ex.printStackTrace();
          out.println(ex.getStackTrace());
        }
        
    }

}
